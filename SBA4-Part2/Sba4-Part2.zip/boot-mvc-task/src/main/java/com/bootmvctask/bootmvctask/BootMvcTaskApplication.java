package com.bootmvctask.bootmvctask;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootMvcTaskApplication {

	public static void main(String[] args) {
		
		
	SpringApplication.run(BootMvcTaskApplication.class, args);
	
	
	
	}

}
