package com.myspr.demo.model;


import javax.persistence.Entity;
import javax.persistence.Id;
	@Entity
	public class Faculty {
		
		@Id
		int facultyId;
		String facultyName;
		String facultySubject;
		
		public Faculty() {
			// TODO Auto-generated constructor stub
		}

		public Faculty(int facultyId, String facultyName, String facultySubject) {
			super();
			this.facultyId = facultyId;
			this.facultyName = facultyName;
			this.facultySubject = facultySubject;
		}

		public int getFacultyId() {
			return facultyId;
		}

		public void setFacultyId(int facultyId) {
			this.facultyId = facultyId;
		}

		public String getFacultyName() {
			return facultyName;
		}

		public void setFacultyName(String facultyName) {
			this.facultyName = facultyName;
		}

		public String getFacultySubject() {
			return facultySubject;
		}

		public void setFacultySubject(String facultySubject) {
			this.facultySubject = facultySubject;
		}

		@Override
		public String toString() {
			return "Faculty [facultyId=" + facultyId + ", facultyName=" + facultyName + ", facultySubject=" + facultySubject
					+ "]";
		}
		
		
		

}
